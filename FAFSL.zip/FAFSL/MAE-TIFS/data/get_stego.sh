# matlab -nosplash -nodesktop -r gh
# matlab -nosplash -nodesktop -r gch
matlab -nosplash -nodesktop -r gsuni
# matlab -nosplash -nodesktop -r gmipod
matlab -nosplash -nodesktop -r gwow
